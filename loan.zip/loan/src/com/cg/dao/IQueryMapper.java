package com.cg.dao;

public class IQueryMapper {

	public static final String INSERT_QUERY = "insert into cust_details values(?,?,?,?,?)";
	public static final String loan_query = "insert into apply_loan values(loanid_seq.nextval,?,?,?) ";
	//public static String loan_query;
	public static final String get_loanid ="SELECT loanid_seq.nextval FROM DUAL";
	public static final String view_query = "select * from cust_details";

}
