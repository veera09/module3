package com.cg.dao;

import com.cg.bean.CustomerDto;
import com.cg.bean.LoanDto;
import com.cg.exceptions.LoanExceptions;

public interface ILoanDao {
	public LoanDto applyLoan(LoanDto loan) throws LoanExceptions;

	public CustomerDto InsertCust(CustomerDto c1) throws LoanExceptions;
}
