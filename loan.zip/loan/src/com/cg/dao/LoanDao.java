package com.cg.dao;

//import java.sql.Connection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;



//import com.capgemini.MobilePurchaseSystem.dao.IQueryMapper;
//import com.capgemini.MobilePurchaseSystem.exceptions.MobilePurchaseSystemException;
import com.cg.bean.CustomerDto;
import com.cg.bean.LoanDto;
import com.cg.exceptions.LoanExceptions;
import com.cg.util.DBConnection;

public class LoanDao implements ILoanDao {

	@Override
	public CustomerDto InsertCust(CustomerDto c1) throws LoanExceptions {
		// TODO Auto-generated method stub
		// CustomerDto c1 = new CustomerDto();
		// logger.info("Customer registration started");
		Connection con;
		PreparedStatement insertStmt = null;
		con = DBConnection.getConnection();
		try {
			// java.util.Date udate = c1.getPurchaseDate();
			// java.sql.Date sdate = new java.sql.Date(udate.getTime());
			double random=Math.random();
			insertStmt = con.prepareStatement(IQueryMapper.INSERT_QUERY);
			insertStmt.setDouble(1, random);
			insertStmt.setString(2, c1.getCusName());
			insertStmt.setString(3, c1.getEmail());
			insertStmt.setString(4, c1.getMobile());
			// insertStmt.setDate(4, sdate);
			insertStmt.setString(5, c1.getAddress());
			int result = insertStmt.executeUpdate();
			if (result != 1) {
				// logger.error("Insertion failed ");
				throw new LoanExceptions("Sorry not inserted!!!");
			} else {
				
				/*
				 * insertStmt = con
				 * .prepareStatement(IQueryMapper.Get_updateQuantity);
				 * insertStmt.setLong(1, c1.getMobileId()); result =
				 * insertStmt.executeUpdate(); con.commit();
				 */
			}
		} catch (SQLException | NullPointerException e) {
			e.printStackTrace();
		}
		// logger.info("details inserted  successfully:");
		return c1;
	}

	@Override
	public LoanDto applyLoan(LoanDto loan) throws LoanExceptions {
		// TODO Auto-generated method stub
		Connection con;
		PreparedStatement insertStmt = null;
		con = DBConnection.getConnection();
		try {
			// java.util.Date udate = c1.getPurchaseDate();
			// java.sql.Date sdate = new java.sql.Date(udate.getTime());

			insertStmt = con.prepareStatement(IQueryMapper.loan_query);

			// insertStmt.setLong(1, loan.getLoanId());
			insertStmt.setDouble(1, loan.getLoanAmount());
			insertStmt.setDouble(2, loan.getCusId());
			insertStmt.setInt(3, loan.getDuration());
			int result1 = insertStmt.executeUpdate();
			if (result1 != 1) {
				// logger.error("Insertion failed ");
				throw new LoanExceptions("Sorry not inserted!!!");
			} else {
				System.out.println("inserted");

			}
		} catch (SQLException | NullPointerException e) {
			e.printStackTrace();
		}

		return loan;
	}

	public int getloanID() throws LoanExceptions, SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int loanID = 0;

		try {
			conn = DBConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapper.get_loanid);
			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				loanID = resultSet.getInt(1);
			}

		} catch (LoanExceptions e) {
			// logger.info("Unable to fetch the purchase Id");
			throw new LoanExceptions("soory not fetching the Purchase Id");

		}
		return loanID;
	}

	public ArrayList<CustomerDto> getdetails() throws LoanExceptions, SQLException {
		CustomerDto dto1 = new CustomerDto();
		Connection conn;
		PreparedStatement viewres = null;
		ResultSet rs = null;
	//	System.out.println("available mobiles are");
		
		// List<String> viewlist1= new ArrayList<String>();
		ArrayList<CustomerDto> viewlist = new ArrayList<CustomerDto>();

		try {
			conn = DBConnection.getConnection();
			viewres = conn.prepareStatement(IQueryMapper.view_query);
			rs = viewres.executeQuery();

			while (rs.next()) {
				dto1.setCusId(rs.getDouble(1));
				System.out.println(rs.getLong(1));
				dto1.setCusName(rs.getString(2));
				dto1.setAddress(rs.getString(3));

				dto1.setMobile(rs.getString(4));

				dto1.setEmail(rs.getString(5));
				
				viewlist.add(dto1);

			}
			

		} finally {
			try {
				rs.close();
				viewres.close();

			} catch (SQLException e) {

				throw new LoanExceptions("Error in closing db connection");

			}
		}

		return viewlist;

	}

}
