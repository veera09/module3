package com.cg.service;

import java.util.List;

import com.cg.entities.Employee;

public interface EmployeeService {

	public Employee save(Employee employee);
	
	public List<Employee> loadAll();
	
	
}
