package com.cg.exception;

public class Course extends Exception{
	public  Course(String msg) {
		super(msg);
	}
}
