package com.cg.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Course;
import com.cg.service.ICourseService;





 @Controller
public class CourseController {
	    @Autowired
		ICourseService courseservice;
	

	 @RequestMapping(value="coursedetails")
		public ModelAndView showAllCourses(){
			List<Course> myAllData=courseservice.display();
			return new ModelAndView("Coursedetails","temp", myAllData);
			}
	 
	 @RequestMapping(value="dosearch")
	 public String displaySucess() {
		 return "sucess";
	 }

 
 
 
 }
 
 
