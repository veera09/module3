package com.cg.dao;

import java.util.List;

import com.cg.bean.Course;
public interface ICourseDao {

	List<Course> display();

}
