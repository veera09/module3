package com.cg.dao;


import java.util.List;
import com.cg.bean.Course;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;


@Repository("coursedao")
public class CourseDaoImpl implements ICourseDao{
	@PersistenceContext
	EntityManager em;

	@Override
	public List<Course> display() {
		// TODO Auto-generated method stub
	    Query query = (Query) em.createQuery("SELECT c FROM Course c");
		List<Course> courses = query.getResultList();
		return courses;
	}

}
