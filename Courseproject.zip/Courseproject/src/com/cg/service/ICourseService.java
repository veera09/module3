package com.cg.service;

import java.util.List;

import com.cg.bean.Course;

public interface ICourseService {

	List<Course> display();

}
