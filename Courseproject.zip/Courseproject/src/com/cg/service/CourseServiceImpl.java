package com.cg.service;

import java.util.List;
import com.cg.bean.*;
import com.cg.service.*;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.dao.ICourseDao;
import com.cg.bean.Course;
public class CourseServiceImpl implements ICourseService {

	
	@Autowired
	ICourseDao cdao;
	@Override
	public List<Course> display() {
		// TODO Auto-generated method stub
		return cdao.display();
	}

}
